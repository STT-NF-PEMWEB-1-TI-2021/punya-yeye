<?php
// definisikan variables
$nama = 'Dhodi Yoga Sahida';
$umur = 20;
$berat = 50.0;

echo 'Nama : ' . $nama;
echo '<br/>Umur : ' . $umur.' Tahun';
echo '<br/>Berat : '.$berat.' Kg';

echo "<br/>Hello $nama Apakabar";

?>